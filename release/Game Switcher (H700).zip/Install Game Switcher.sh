#!/bin/bash
set -euo pipefail

# configuration variables
TOOLS_DIR=/userdata/roms/tools
GAME_SWITCHER_DIR=$TOOLS_DIR/game-switcher
BACKUP_DIR=$GAME_SWITCHER_DIR/backup

# extract the package
mkdir -p $GAME_SWITCHER_DIR
unzip $TOOLS_DIR/game-switcher.zip -d $GAME_SWITCHER_DIR

# display our friendly splash page
$GAME_SWITCHER_DIR/splash $GAME_SWITCHER_DIR/splash.png

# create backup of ES binaries, scripts, and configuration files
mkdir -p $BACKUP_DIR
[ ! -f $BACKUP_DIR/emulationstation ] && cp /usr/bin/emulationstation $BACKUP_DIR/
[ ! -f $BACKUP_DIR/dpad-toggle ] && cp /usr/bin/dpad-toggle $BACKUP_DIR/
[ ! -f $BACKUP_DIR/multimedia_keys.conf ] && cp /etc/triggerhappy/triggers.d/multimedia_keys.conf $BACKUP_DIR/

# stop ES service, wait before copying the binaries and scripts to ensure the service has fully stopped
/etc/init.d/S31emulationstation stop
sleep 3

# copy new binaries, scripts, and configuration files
cp $GAME_SWITCHER_DIR/emulationstation /usr/bin/
cp $GAME_SWITCHER_DIR/knulli-game-switcher /usr/bin/
cp $GAME_SWITCHER_DIR/dpad-toggle /usr/bin/
cp $GAME_SWITCHER_DIR/dpad-toggle-release /usr/bin/
cp $GAME_SWITCHER_DIR/multimedia_keys.conf /etc/triggerhappy/triggers.d/

# set permissions for the binary and scripts
chmod +x /usr/bin/emulationstation
chmod +x /usr/bin/knulli-game-switcher
chmod +x /usr/bin/dpad-toggle
chmod +x /usr/bin/dpad-toggle-release

# remove the archive and script
# rm -rf $TOOLS_DIR/game-switcher.zip
# rm -rf $TOOLS_DIR/Install\ Game\ Switcher.sh

# save changes to the image and reboot to apply the changes
knulli-save-overlay
reboot